﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tip_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {

            double mealUserInput;
            double tipPctUserInput;
            double tipAmountCalculated;
            double mealCalculatedTotalCost;

            Console.Title = "Tip Calculator Application";

            Console.WriteLine("Please enter the cost of your meal: ");

            mealUserInput = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("What Pct would you like to tip: ?");

            tipPctUserInput = Convert.ToDouble(Console.ReadLine());

            tipAmountCalculated = ((tipPctUserInput / 100) * mealUserInput);

            Console.WriteLine("The tip amount based on the cost of your meal should be: ${0}", Math.Round(tipAmountCalculated,2));

            mealCalculatedTotalCost = mealUserInput + tipAmountCalculated;

            Console.WriteLine("The total cost of the meal with tip is: ${0}", Math.Round(mealCalculatedTotalCost,2));

            Console.ReadLine();
        }
    }
}
